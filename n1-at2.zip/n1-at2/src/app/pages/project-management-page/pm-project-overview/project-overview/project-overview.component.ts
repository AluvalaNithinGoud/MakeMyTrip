import { Component } from '@angular/core';

@Component({
    selector: 'app-project-overview',
    standalone: true,
    imports: [],
    templateUrl: './project-overview.component.html',
    styleUrl: './project-overview.component.scss'
})
export class ProjectOverviewComponent {}