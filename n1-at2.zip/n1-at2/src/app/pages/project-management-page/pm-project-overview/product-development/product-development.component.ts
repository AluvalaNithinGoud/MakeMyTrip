import { Component } from '@angular/core';

@Component({
    selector: 'app-product-development',
    standalone: true,
    imports: [],
    templateUrl: './product-development.component.html',
    styleUrl: './product-development.component.scss'
})
export class ProductDevelopmentComponent {}