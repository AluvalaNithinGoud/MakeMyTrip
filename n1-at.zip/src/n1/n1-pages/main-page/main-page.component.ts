import { Component } from "@angular/core";
import { N1RadioGroupComponent } from "../../n1-comps/n1-radio-group";
import { Router, RouterLink, RouterOutlet } from "@angular/router";
import { N1RadioComponent } from "../../../app/inputs/elements/n1-radio";
import { N1FromComponent } from "../../n1-comps/n1-from";
import { N1ToComponent } from "../../n1-comps/n1-to";
import { N1SwapButtonComponent } from "../../n1-comps/n1-swap-button";
import { N1DepartureReturnComponent } from "../../n1-comps/n1-departure-return";
import { N1TravellersClassComponent } from "../../n1-comps/n1-travellers-class";
import { N1DropdownAirportComponent, N1DropdownOptions } from "../../n1-comps/n1-dropdown-airport";
import { N1DropdownComponent } from "../../../app/inputs/elements/n1-dropdown";
import { N1DetailsInputComponent } from "../../n1-comps/n1-details-input";
import { NgForm } from "@angular/forms";
import { FormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from "@angular/common";
import { N1CompanyLogo } from "../../n1-comps/n1-company-logo";
import { N1TimingsComponent } from "../../n1-comps/n1-timings";
import { N1PriceComponent } from "../../n1-comps/n1-price-component";
import { N1JourneyTimeComponent } from "../../n1-comps/n1-journey-time";
import { N1FlightSelect, Detailsoptions } from "../../n1-comps/n1-flight-select";
import { bookingoptions, N1CompleteBookingComponent } from "../../n1-comps/n1-complete-booking";
import { cancellationoptions, N1CancellationComponent } from "../../n1-comps/n1-cancellation";
import { addonoptions, N1AddOnsComponent } from "../../n1-comps/n1-add-ons";
import { N1ImpInformationComponent } from "../../n1-comps/n1-imp-information";
import { N1VipComponent, vipoptions } from "../../n1-comps/n1-vip";
import { N1TravellersDetailsComponent, travellersoptions } from "../../n1-comps/n1-travellers-details";
import { fareoptions, N1FareSummaryComponent } from "../../n1-comps/n1-fare-summary";
import { N1PromoCodeComponent, promooptions } from "../../n1-comps/n1-promo-code";
import { filteroptions, N1PopularFiltersComponent } from "../../n1-comps/n1-popular-filters";
import { N1OnwardReturnFilterComponent, onwardreturnoptions } from "../../n1-comps/n1-onward-return-filter";
import { N1HotelFilterComponent } from "../../n1-comps/n1-hotels/n1-hotel-filters";
import { N1PopularHotelComponent, popularoptions } from "../../n1-comps/n1-hotels/n1-popular-hotels";
import { bookingreviewoptions, N1ReviewBookingComponent } from "../../n1-comps/n1-hotels/n1-review-booking";
import { guestdataoptions, N1GuestDetailsComponent } from "../../n1-comps/n1-hotels/n1-guest-details";
import { N1SpecialRequestComponent, requestoptions } from "../../n1-comps/n1-hotels/n1-special-request";
import { N1TripSecureComponent, secureoptions } from "../../n1-comps/n1-hotels/n1-trip-secure";
import { paymentmodes, N1PaymentOptionsComponent } from "../../n1-comps/n1-hotels/n1-payment-options";
import { N1PayNowComponent, paynowoptions } from "../../n1-comps/n1-hotels/n1-pay-now";
 

@Component({
  selector: 'main-page',
  standalone: true,
  imports: [N1RadioGroupComponent, RouterOutlet, CommonModule, RouterLink, N1RadioComponent, N1FromComponent, N1ToComponent, N1SwapButtonComponent, N1DepartureReturnComponent, N1TravellersClassComponent, N1DropdownAirportComponent, N1DetailsInputComponent, FormsModule, DatePipe, N1CompanyLogo, N1TimingsComponent, N1PriceComponent, N1JourneyTimeComponent, N1FlightSelect, N1CompleteBookingComponent, N1CancellationComponent, N1AddOnsComponent, N1ImpInformationComponent, N1VipComponent, N1TravellersDetailsComponent, N1FareSummaryComponent, N1PromoCodeComponent, N1PopularFiltersComponent, N1OnwardReturnFilterComponent, N1HotelFilterComponent, N1PopularHotelComponent, N1ReviewBookingComponent, N1GuestDetailsComponent, N1SpecialRequestComponent, N1TripSecureComponent, N1PaymentOptionsComponent, N1PayNowComponent],
  templateUrl: './main-page.component.html',
  styleUrl: './main-page.component.scss',
})
export class MainPageComponent {

  flyOptions = [
    'One Way',
    'Round Trip',
    'Multi City',
  ];
  selectedFlyOption: string = "";


  selectedDepartureReturnDates: Date[] | null = null;

  onDatesChange(selectedDates: Date[]): void {
    this.selectedDepartureReturnDates = selectedDates;
  }



  fromDropdownOptions: N1DropdownOptions[] = [
    {
      id: 1,
      name: 'Hyderabad',
      cityDetails: 'HYD, Hyderabad Airport India',
    },
    {
      id: 2,
      name: 'Bangalore',
      cityDetails: 'Blr, Blr Airport India',
    },
    { id: 3, name: 'Mumbai', cityDetails: 'Mum,  Mumbai Airport India' },
    {
      id: 4,
      name: 'Chennai',
      cityDetails: 'Chennai, Chennai Airport India',
    },
  ];

  toDropdownOptions: N1DropdownOptions[] = [
    {
      id: 1,
      name: 'Hyderabad',
      cityDetails: 'HYD, Hyderabad Airport India',
    },
    {
      id: 2,
      name: 'Bangalore',
      cityDetails: 'Blr, Blr Airport India',
    },
    { id: 3, name: 'Mumbai', cityDetails: 'Mum,  Mumbai Airport India' },
    {
      id: 4,
      name: 'Chennai',
      cityDetails: 'Chennai, Chennai Airport India',
    },
  ];

  seatsbooking: N1DropdownOptions[] = [

    {
      id: 1,
      name: '1',
      cityDetails: '',
    },
    {
      id: 2,
      name: '2',
      cityDetails: '',
    },
    {
      id: 3,
      name: '3',
      cityDetails: '',
    },
    {
      id: 3,
      name: '4',
      cityDetails: '',
    },
    {
      id: 3,
      name: '5',
      cityDetails: '',
    },

  ];
  classbooking: N1DropdownOptions[] = [

    {
      id: 1,
      name: 'Economy',
      cityDetails: '',
    },
    {
      id: 2,
      name: 'Premium Economy',
      cityDetails: '',
    },
    {
      id: 3,
      name: ' Business',
      cityDetails: '',
    },
    {
      id: 3,
      name: 'First Class',
      cityDetails: '',
    },


  ];

   countrycode: N1DropdownOptions[] = [

    {
      id: 1,
      name: 'India(91) ',
      cityDetails: '',
    },
    {
      id: 2,
      name: 'Afghanisthan(93)',
      cityDetails: '',
    },
    {
      id: 3,
      name: 'Ageria(213)',
      cityDetails: '',
    },
    {
      id: 3,
      name: 'Ageria(213)',
      cityDetails: '',
    },


  ];

 
  genderOptions = [
    'Regular',
    'Student',
    '  Senior Citizen',
    'Armed Forces',
    'Doctor and Nurses',
  ];

  firstName: string = '';
  lastname: string = '';
  number: string = '';
  email: string = '';

  onSubmit(form: NgForm) {
    if (form.valid) {
      console.log('Form Submitted:', form.value);
    } else {
      console.log('Form is invalid');
    }
  }

  selectedFrom = this.fromDropdownOptions[1];
  selectedTo = this.toDropdownOptions[3];
  seatNumbers = this.seatsbooking[1]
  classes = this.classbooking[1]
  selectedGender = this.genderOptions[0]
  // selectedcode= this.countrycode[0]

  flightdetails: Detailsoptions[] = [
    {
      from: "Mumbai",
      to: "Delhi",
      name: " Indigo",
      logo: '',
      start_time: '00.35',
      end_time: '12:23',
      amount: ' 7,544'
    },
    {
      from: "Hyderabad",
       to: "Mumbai",
      name: "Indigo",
      logo: '',
      start_time: '03:44',
      end_time: '07:44',
      amount: '1000'
    },  

  ]

   completebookingoptions:  bookingoptions [] = [
    {
      destination: "Mumbai → New Delhi",
      booking_date: "Saturday, Feb 15",
      logo: "",
      time: 'Non Stop · 2h 25m',
      travel_time:"2h 25m",
      name: "IndiGo" ,
      start_place: "Mumbai " ,
      from_airportname: ".Chhatrapati Shivaji International Airport, Terminal T2",
      end_place:  "New Delhi",
      to_airportname:".Indira Gandhi International Airport, Terminal T3",
      flightnum:"6E 6218",
      airbus:"Airbus A320 N",
      start_time:'00.35',
      end_time: '12:23',
      cabinbaggage:"Cabin Baggage:",
      Checkinbaggage:"Check-In Baggage:",
      cabinbaggage_details:"7 Kgs (1 piece only) / Adult",
      checkbaggage_details:"15 Kgs / Adult",
      conditions:"Got excess baggage? Don’t stress, buy extra check-in baggage allowance for BOM-DEL at fab rates!",
      refund:"REFUNDABLE",
      economy:"Economy >",
      eco:"ECO VALUE"
    },
    {
      destination: "New Delhi → Mumbai",
      booking_date: "Saturday, Feb 18",
      logo: "",
      time: 'Non Stop · 2h 25m',
      travel_time:"2h 25m",
      name: "IndiGo" ,
      start_place: " New Delhi " ,
      from_airportname: ".Indira Gandhi International Airport, Terminal T3",
      end_place:  "Mumbai ",
      to_airportname:".Chhatrapati Shivaji International Airport, Terminal T2",
      flightnum:"6E 6218",
      airbus:"Airbus A321 N",
      start_time:'06.35',
      end_time: '08:00',
      cabinbaggage:"Cabin Baggage:",
      Checkinbaggage:"Check-In Baggage:",
      cabinbaggage_details:"7 Kgs (1 piece only) / Adult",
      checkbaggage_details:"15 Kgs / Adult",
      conditions:"Got excess baggage? Don’t stress, buy extra check-in baggage allowance for BOM-DEL at fab rates!",
      refund:"REFUNDABLE",
      economy:"Economy >",
      eco:"ECO VALUE"
    },
   ]


   cancel : cancellationoptions [] = [
    {
    name:"Cancellation & Date Change Policy",
    logo:"",  
    destination:"BOM-DEL",
    penalty:"Cancellation Penalty :",
    penalty_1: "₹ 0",
    penalty_2: "₹ 2000",
    penalty_3:" ₹ 4000",
    cancel_ist:"Cancel Between (IST) :",
     now:"Now",
     canceldate1:"28 Jan",
     canceltime1:"09:45",
     canceldate2:"14 Feb",
     canceltime2:"13:45",
     canceldate3:"14 Feb",
     canceltime3:"15:45",
    },
    {
      name:" ",
      logo:"",  
      destination:"DEL-BOM",
      penalty:"Cancellation Penalty :",
      penalty_1: "₹ 0",
      penalty_2: "₹ 2000",
      penalty_3:" ₹ 4000",
      cancel_ist:"Cancel Between (IST) :",
       now:"Now",
       canceldate1:"28 Jan",
       canceltime1:"09:45",
       canceldate2:"14 Feb",
       canceltime2:"13:45",
       canceldate3:"14 Feb",
       canceltime3:"15:45",
      },

   ]

  addons : addonoptions [] = [
    {
      name:"Unsure of your travel plans?",
      subname:"Get full flexibility with our special add-ons",
      logo:"",
      Zero_cancel:"Zero Cancellation",
      coupon:"Get Zero Cancellation with coupon HSBCZC",
      get_refund:"Great! Get refund of up to ₹ 10,270",
      in_case:"in case of cancellation up to 24 hours before departure!",
      terms:"View T&C",
      price:"₹ 1,345",
    },
    {
      name:" ",
      subname:" ",
      logo:"",
      Zero_cancel:"Free Date Change",
      coupon:" ",
      get_refund:"Great! Get refund of up to ₹ 10,270",
      in_case:"in case of cancellation up to 24 hours before departure!",
      terms:"View T&C",
      price:"₹ 1,245",
    },
    {
      name:" ",
      subname:" ",
      logo:"",
      Zero_cancel:"FlexiFly",
      coupon:"Get Zero Cancellation with coupon HSBCZC",
      get_refund:"Great! Get refund of up to ₹ 10,270",
      in_case:"in case of cancellation up to 24 hours before departure!",
      terms:"View T&C",
      price:"₹ 1,545",
    },
  ]

   flylike : vipoptions [] = [
    {
      name:"Fly Like a VIP @ Just ₹ 450",
      logo:"",
      desicription:"Be amongst the first to check-in and get your bags tagged with priority status with Akasa Air Priority Check-in & Bag Services.",
      checkin:"Priority Check-in",
      symbol:"+",
      bag_service:"Priority Bag Service",
      Equal:"=",
      amount:" ₹ 450",    
    }
   ]

    travellers :  travellersoptions [] = [
      {
        name:" Traveller Details",
      logo:"",
      audlt:"ADULT (12 yrs+)",
      conditions:"Important:",
      context:"Enter name as mentioned on your passport or Government approved IDs.Please ensure that the Frequent Flyer No entered here is against the same passenger name otherwise the points will not be updated by the airline.",
      adult_1:"ADULT 1",
      firstName:'',
      lastname:'',
      number:'',
      email:'',
      }
    ]

     summary :   fareoptions [] = [
      {
        name:" Fare Summary",
      logo:"",
       base:"Base Fare",
       sub_base:"Adult(s) (1 X ₹ 9,846):",
       price:" ₹ 9,846",
      tax:"Taxes and Surcharges",
       air_line_tax:"Airline Taxes and Surcharges",
        price1:" ₹ 9,846",
      total_amount:"Total Amount",
      total_price:"₹ 11,279",
      desicription:" The airfare has increased by ₹ 985.Please review baggage allowance, cancellation policies & other ticket inclusions ",
      }
    ];


     promocodes :    promooptions [] = [
      {
        name:"PROMO",
        subname:"CODES",
        firstName:'',
      
      }
    ];

     popular :    filteroptions [] = [
      {
        name:"Popular Filters",
         nonstop:" Non Stop",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" Refundable Fares",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" IndiGo",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" Air India",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" Morning Departures",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:"AfterNoon Departure",
         price:" ₹ 9,846",
      },
      
      
      
      {
        name:" Airlines",
         nonstop:"Air India",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" Air India Express",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" IndiGo",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" Air India",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:" Akasa Air",
         price:" ₹ 9,846",
      },
      {
        name:" ",
         nonstop:"SpiceJet",
         price:" ₹ 9,846",
      }


    ];
    selectedfliter :string = "";

     onwardfilters :   onwardreturnoptions [] = [
      {
        name:"Onward Journey",
       stops:"Stops From Mumbai",
       departure:"Departure From Mumbai",
       before:"Before ",
       before1:"6 AM",
       morningtime:"6 AM to  ",
       morningtime1:"  12 PM",
       afterNoon:"12 PM to  ",
       afterNoon1:" 6 PM",
        night:"After  ",
        night1:" 6 PM",
       arrival:"Arrival at  New Delhi",
       departure_air:"Departure Airports",
      },

      {
        name:"Return Journey",
       stops:"Stops From New Delhi",
       departure:"Departure From  New Delhi",
       before:"Before ",
       before1:"6 AM",
       morningtime:"6 AM to  ",
       morningtime1:"  12 PM",
       afterNoon:"12 PM to  ",
       afterNoon1:" 6 PM",
        night:"After  ",
        night1:" 6 PM",
       arrival:"Arrival at Mumbai",
       departure_air:"Departure Airports",
      }
    ];

  hotelfilters = {
    suggested:[
      
      { name:"  ", nonstop:" Last Minute Deals", price:"   ", },
      { name:"  ", nonstop:"Highly Recommeded by Couple Travellers", price:" (47)  ", },
      { name:"  ", nonstop:"Unmarried Couples Allowed", price:" (1510) ", },
      { name:"  ", nonstop:"3 Star", price:" (33) ", },
      { name:"  ", nonstop:"MMT ValueStays - Top Rated & Affordable", price:" (334) ", },
      { name:"  ", nonstop:"Breakfast Included", price:" (140) ", },
      { name:"  ", nonstop:"Free Cancellation", price:" (140) ", },
    ],
     price_per_night:[
      
      { name:"  ", nonstop:" ₹ 0 - ₹ 4000", price:" (143)  ", },
      { name:"  ", nonstop:" ₹ 4000 - ₹ 8000", price:" (27)  ", },
      { name:"  ", nonstop:"₹ 8000 - ₹ 12000", price:" (0) ", },
      { name:"  ", nonstop:" ₹ 12000 - ₹ 16000", price:" (0) ", },
      
    ],

    star_category:[
      
      { name:"  ", nonstop:"3 Star", price:" (113)  ", },
      { name:"  ", nonstop:" 4 Star", price:" (27)  ", },
      { name:"  ", nonstop:"5 star", price:" (0) ", },
 
      
    ],

    super_packages:[
      { name:"  ", nonstop:"Super Packages", price:" (3)  ", }  
    ],


    user_rating:[
      { name:"  ", nonstop:"Excellent: 4.2+ ", price:" (23)  ", } , 
      { name:"  ", nonstop:"VeryGood: 3.5+ ", price:" (13)  ", }  ,
      { name:"  ", nonstop:"Good: 3+ ", price:" (13)  ", },  
    ],



    property_type:[
      { name:"  ", nonstop:"Hotel ", price:" (2)  ", } , 
      { name:"  ", nonstop:"Apartment ", price:" (0)  ", }  ,
      { name:"  ", nonstop:"Villa", price:" (0)  ", },  
    ],


    chains:[
      { name:"  ", nonstop:"Accor - Novotel & ibis ", price:" (2)  ", } , 
      { name:"  ", nonstop:"Best Western ", price:" (0)  ", }  ,
      { name:"  ", nonstop:"Bloom Hotels", price:" (0)  ", },  
      { name:"  ", nonstop:"Bluekite ", price:" (2)  ", } , 
      { name:"  ", nonstop:"Concept Hospitality ", price:" (0)  ", }  ,
      { name:"  ", nonstop:"Cygnett Group", price:" (0)  ", },  
      { name:"  ", nonstop:"Elivaas ", price:" (2)  ", } , 
      { name:"  ", nonstop:"Fab hotels ", price:" (0)  ", }  ,
      { name:"  ", nonstop:"Fortune", price:" (0)  ", },  
      { name:"  ", nonstop:"Ginger Hotels ", price:" (2)  ", } , 
      { name:"  ", nonstop:"GoStops ", price:" (0)  ", }  ,
      { name:"  ", nonstop:"Hilton & Doubletree", price:" (0)  ", },  
      { name:"  ", nonstop:"Hostie ", price:" (2)  ", } , 
      { name:"  ", nonstop:"Hyatt ", price:" (0)  ", }  ,
      { name:"  ", nonstop:"IHG - Crowne Plaza, Holiday Inn & Intercontinental", price:" (0)  ", },  
      { name:"  ", nonstop:"Justa", price:" (0)  ", },  
      { name:"  ", nonstop:"Lemon Tree ", price:" (2)  ", } , 
      { name:"  ", nonstop:"Marriott, Westin & Le Meridien ", price:" (0)  ", }  ,
    ],



    locality:[
      { name:"  ", nonstop:"Karol bagh ", price:"  ", } , 
      { name:"  ", nonstop:"Lajpat Nagar ", price:"    ", }  ,
      { name:"  ", nonstop:"Mehrauli", price:"    ", },  
    ],

    shopping:[
      { name:"  ", nonstop:"Connaught Place ", price:"  ", } , 
      { name:"  ", nonstop:"Chandni Chowk ", price:"    ", }  ,
      { name:"  ", nonstop:"South Delhi", price:"    ", },  
      { name:"  ", nonstop:"Green Park", price:"    ", },  
    ],


    transit_hub:[
      { name:"  ", nonstop:"Aerocity ", price:"  ", } , 
      { name:"  ", nonstop:" T1 - Delhi Airport (IGI Airport)" , price:"    ", }  ,
      { name:"  ", nonstop:" T2 - Delhi Airport (IGI Airport)", price:"    ", },  
      { name:"  ", nonstop:" T3 - Delhi Airport (IGI Airport)", price:"    ", }, 
      { name:"  ", nonstop:"New Delhi Railway Station", price:"  ", } , 
      { name:"  ", nonstop:"Old Delhi Railway Station", price:"    ", }  ,
      { name:"  ", nonstop:"ISBT Kashmere Gate", price:"    ", },  
      { name:"  ", nonstop:"Hazrat Nizamuddin Railway Station", price:"    ", },  
      { name:"  ", nonstop:"Sarai Rohilla Railway Station ", price:"  ", } , 
      { name:"  ", nonstop:"Paharganj ", price:"    ", }  ,
      { name:"  ", nonstop:"Mahipalpur", price:"    ", },  
      
    ],

    guests_love:[
      { name:"  ", nonstop:"Wi-Fi", price:"  ", } , 
      { name:"  ", nonstop:"Spa ", price:"    ", }  ,
      { name:"  ", nonstop:"Swimming Pool", price:"    ", },  
     
    ],


    house_rules:[
      { name:"  ", nonstop:"Smoking Allowed", price:" (22) ", } , 
      { name:"  ", nonstop:"Unmarried Couples Allowed ", price:"  (32)  ", }  ,
      { name:"  ", nonstop:"Pets Allowed", price:"   (22) ", },  
      { name:"  ", nonstop:"Alcohol Allowed", price:"     (22) ", },
     
    ],

    booking_preference:[
      { name:"  ", nonstop:" Entire Property", price:" (2) ", } , 
      { name:"  ", nonstop:"CareTaker ", price:"  (2)  ", }  ,
      { name:"  ", nonstop:"Instant Book", price:"   (2) ", },  
      { name:"  ", nonstop:"HomeStays", price:"     (2) ", },
     
    ],

    
    room_views:[
      { name:"  ", nonstop:"Garden View", price:" (2) ", } , 
      { name:"  ", nonstop:"City View ", price:"  (2)  ", }  ,
    ],


    room_amenities:[
      { name:"  ", nonstop:"Cook & Butler Service", price:" (2) ", } , 
      { name:"  ", nonstop:"Home Theatre ", price:"  (2)  ", }  ,
      { name:"  ", nonstop:"Spa Tub", price:" (2) ", } , 
      { name:"  ", nonstop:"Kitchenette ", price:"  (2)  ", }  ,
      { name:"  ", nonstop:"Fireplace", price:" (2) ", } , 
      { name:"  ", nonstop:"Smoking Room ", price:"  (2)  ", }  ,
      { name:"  ", nonstop:"Bathtub", price:" (2) ", } , 
      { name:"  ", nonstop:"Jacuzzi ", price:"  (2)  ", }  ,
      { name:"  ", nonstop:"Private Pool", price:" (2) ", } , 
      { name:"  ", nonstop:"Living Area", price:"  (2)  ", }  ,
      { name:"  ", nonstop:"Interconnected Room", price:" (2) ", } , 
      { name:"  ", nonstop:"Heater ", price:"  (2)  ", }  ,
      
    ],
  }


   popularhotles : popularoptions [] = [
    {
      name:"Popular in Delhi",
      mmt:"MMT ValueStays",
      sponsored:"SPONSORED",
      hotelname:"The Lohmod - Boutique Hotel At Delhi Airport",
      img1:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img2:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img3:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img4:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img5:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
       areaname:"Mahipalpur |",
       distance:"4.4 km drive to Indira Gandhi International Airport!",
       restaurant:"Restaurant",
       free_cancellation:"Free Cancellation till check-in",
        book:"Book with ₹0 Payment",
         discount:"10% Discount on F&B services",
         convenient:"Convenient location, good food & excellent staff",
         offer:"HSBC Bank Credit Card NoCostEMI Offer - Get INR 2596 Off",
         very_good:"Very Good",
             hotel_rating:"3.9",
             emi: " No Cost EMI"  ,
             actual_price: "₹ 7,499"  ,
             real_price:"₹ 2,767" ,
    },

    {
      name:" ",
      mmt:"MMT ValueStays",
      sponsored:"SPONSORED",
      hotelname:"Qotel Hotel Church House Rohini Sector 15",
      img1:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img2:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img3:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img4:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
      img5:"https://plus.unsplash.com/premium_photo-1661964071015-d97428970584?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aG90ZWx8ZW58MHx8MHx8fDA%3D",
       areaname:"Mahipalpur |",
       distance:"4.4 km drive to Indira Gandhi International Airport!",
       restaurant:"Restaurant",
       free_cancellation:"Free Cancellation till check-in",
        book:"Book with ₹0 Payment",
         discount:"10% Discount on F&B services",
         convenient:"Convenient location, good food & excellent staff",
         offer:"HSBC Bank Credit Card NoCostEMI Offer - Get INR 2596 Off",
         very_good:"Very Good",
             hotel_rating:"3.9",
             emi: " No Cost EMI"  ,
             actual_price: "₹ 7,499"  ,
             real_price:"₹ 2,767" ,
    },
  ]
   booking_review :   bookingreviewoptions [] = [
    {
      hotel_name:"The Lohmod - Boutique Hotel At Delhi Airport",
      friendly:"Couple Friendly",
      address:"A-292, NH-8, Near IGI Airport, Aerocity, Mahipalpur, New Delhi, India 110037, Delhi, India",
      img1:"https://r2imghtlak.mmtcdn.com/r2-mmt-htl-image/htl-imgs/201908061717592701-16c8dee4bb7a11ee89970a58a9feac02.jpg",
      checkin:"CHECK IN ",
      day:"SUN",
      date:"9 Feb ",
     year:" 2025",
      time:"12 PM    ",
      checkout:"CHECK OUT ",
      day1:"SUN",
      date1:"12 Feb ",
     year1:" 2025",
      time1:"12 PM    ",
      night:"3 Night   ",
       adult:" | 1 Adult | ",
       room:"1 Room",
       deluxe:"Deluxe Double Room",
       free: "Room With Free Cancellation",
    meals: "No meals included",
    discount: "10% Discount on F&B services",
    free_cancellation:"Free Cancellation till check-inCancellation policy details Book with ₹0 Payment. Pay before 08 Feb, 11:59 PM IST to avoid auto-cancellation. Payment can only be done on MakeMyTrip.",
    bar:"100% Refund",
    imp:   "Important information"  ,
   passport: " Passport, Aadhar, Driving License and Govt. ID are accepted as ID proof(s)",
   pets:  "Pets are not allowed",
   Unmarriedc:  "Unmarried couples allowed",
  local: "Local ids are allowed",
     
    },
  ]

   details :   guestdataoptions [] = [
    {
      name:"Guest Details",
      myself:" My Self",
      someone:"Someone Else",
      title:"Title ",
      firstName:" ",
      lastname:" ",
      email:"",
      number:"12 PM to  ",
      countrycode:"Countrycode",
      enter:"Enter GST Details",
     
    },
  ]

   special :  requestoptions [] = [
    {
      name:"Special Request",
       desicription:" Special requests are subject to each hotel's availability, may be chargeable & can't be guaranteed.",
       common:"Commonly Requested",
       anyother:"Any other request?",
      firstName:" ",
     
    },
  ]


   secure :   secureoptions [] = [
    {
      name:"Trip Secure",
       desicription:" Excited to travel solo? Make sure to secure your trip against sudden events!",
        enjoy:"Enjoy a Worry-Free Stay",
        loss:  "Loss of Laptop/Tablet",
        medical:  "Medical Assistance",
        refund:  "Refund on Hotel Cancellation",
        personal:   "Personal Accident",
        price1:"Rs 25,000",
      support:"24*7 SUPPORT",
      price2:"Rs 15,000",
      price3:"Rs 10,00,000",
      price4:"₹237",
      per:"per guest",
      non:"Non Refundable I 18% GST Included",
        yes:"Yes, secure my trip.",
       no:"No, I will book without trip secure."
       // enter:"Enter GST Details",
     
     
    },
  ]

     payment :   paymentmodes [] = [
    {
      name:"Payment Options",
        pay:"Pay Full Amount Now and save ₹91",
        cancel:"Cancel for free any time before 09 Feb",
         book:  "Book with ₹0 Payment",
        remaining:  "Pay the remaining amount of ₹ 9,539 using any payment options before 08 Feb, 2025, 11:59 PM IST to avoid auto cancellation",
        price1:  "₹9,448",
        price2:   "₹9,539",
      
     
     
    },
  ]

   paynow :   paynowoptions [] = [
    {
       discription:"By proceeding, I agree to MakeMyTrip’s",
       user:" User Agreement, Terms of Service",
        and:"and",
        cancellation :  " Cancellation & Property Booking Policies.",
      //   remaining:  "Pay the remaining amount of ₹ 9,539 using any payment options before 08 Feb, 2025, 11:59 PM IST to avoid auto cancellation",
      //   price1:  "₹9,448",
      //   price2:   "₹9,539",
      
     
     
    },
  ]

}



 