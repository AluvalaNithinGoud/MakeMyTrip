import { Component } from '@angular/core';

@Component({
    selector: 'app-team-members',
    standalone: true,
    imports: [],
    templateUrl: './team-members.component.html',
    styleUrl: './team-members.component.scss'
})
export class TeamMembersComponent {}